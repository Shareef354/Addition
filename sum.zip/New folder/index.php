<!DOCTYPE html>
<html lang="en">

<title>operator</title>
	<link rel="stylesheet" href="operator.php">

<body>

<h1>this is a home page welcome to the operator</h1>
<button type="button" > 
	<a href="operator.php"> click here to enter </a></button>



</body>
</html>


