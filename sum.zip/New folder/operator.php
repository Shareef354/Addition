<!DOCTYPE html>
<html lang="en">

<title>operator</title>
	<!-- <link rel="stylesheet" href="operator.php"> -->
<body>

<form>
    <input type="number" name="number_one" placeholder="Enter first number">Number 1:</input><br>
    <input type="number" name="number_two" placeholder="Enter second number">Number 2:</input><br>
    <button type="submit"  href="process.php">Sum</button>
</form>
</body>
</html>
