<?php 
echo $_GET['$anser']
?>